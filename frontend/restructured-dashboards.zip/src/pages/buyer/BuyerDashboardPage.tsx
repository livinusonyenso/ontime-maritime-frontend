"use client"

import { useEffect } from "react"
import { useNavigate } from "react-router-dom"
import { useAuth } from "@/contexts/auth-context"
import { useTracking } from "@/contexts/tracking-context"
import { useDocument } from "@/contexts/document-context"
import { useNotification } from "@/contexts/notification-context"

// Buyer-specific dashboard components
import {
  BuyerDashboardHeader,
  BuyerStatCard,
  BuyerShipmentChart,
  BuyerShipmentList,
  BuyerQuickActions,
  BuyerAlerts,
  BuyerSupportCard,
} from "@/features/buyer-dashboard/components"

import { Ship, FileText, ShoppingCart, Shield } from "lucide-react"

// Mock chart data
const shipmentChartData = [
  { name: "Jan", shipments: 4, delivered: 3 },
  { name: "Feb", shipments: 3, delivered: 3 },
  { name: "Mar", shipments: 2, delivered: 2 },
  { name: "Apr", shipments: 6, delivered: 5 },
  { name: "May", shipments: 8, delivered: 7 },
  { name: "Jun", shipments: 5, delivered: 4 },
]

export default function BuyerDashboardPage() {
  const { user, isAuthenticated, loading, logout } = useAuth()
  const { trackingData } = useTracking()
  const { documents } = useDocument()
  const { unreadCount } = useNotification()
  const navigate = useNavigate()

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      navigate("/login")
    }
  }, [isAuthenticated, loading, navigate])

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="relative h-16 w-16">
            <div className="absolute inset-0 animate-ping rounded-full bg-cyan-400 opacity-20"></div>
            <div className="relative flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-cyan-500 to-teal-500">
              <Ship className="h-8 w-8 text-white animate-pulse" />
            </div>
          </div>
          <p className="text-sm text-slate-500 dark:text-slate-400">Loading your dashboard...</p>
        </div>
      </div>
    )
  }

  if (!isAuthenticated) return null

  const userName = user?.first_name || "Buyer"

  // Transform tracking data for shipment list
  const shipmentItems = trackingData.length > 0
    ? trackingData.slice(0, 5).map((item: any) => ({
        id: item.id,
        container_number: item.container_number,
        vessel_imo: item.vessel_imo,
        status: item.status || "In Transit",
        location: item.location || "Location tracking...",
        timestamp: item.timestamp,
        eta: item.eta,
      }))
    : undefined // Use default data from component

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white dark:from-slate-950 dark:to-slate-900">
      <div className="mx-auto max-w-7xl space-y-8 p-4 md:p-8">
        {/* Header Section */}
        <BuyerDashboardHeader
          userName={userName}
          unreadNotifications={unreadCount}
          onLogout={logout}
        />

        {/* Stats Grid */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <BuyerStatCard
            title="Active Shipments"
            value={trackingData.length > 0 ? trackingData.length : 3}
            icon={Ship}
            variant="primary"
            trend={{ value: "+2 this week", positive: true }}
            subtitle="Cargo in transit"
          />
          <BuyerStatCard
            title="Pending Documents"
            value={documents.length > 0 ? documents.length : 5}
            icon={FileText}
            variant="warning"
            subtitle="Requires attention"
          />
          <BuyerStatCard
            title="Active Bids"
            value={4}
            icon={ShoppingCart}
            variant="success"
            trend={{ value: "3 closing soon", positive: true }}
            subtitle="In marketplace auctions"
          />
          <BuyerStatCard
            title="Insurance Coverage"
            value="2"
            icon={Shield}
            variant="default"
            subtitle="Active policies"
          />
        </div>

        {/* Main Content Grid */}
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Left Column - Charts & Lists */}
          <div className="space-y-8 lg:col-span-2">
            {/* Shipment Activity Chart */}
            <BuyerShipmentChart
              data={shipmentChartData}
              title="Shipment Activity"
              description="Track your shipping volume over the past 6 months"
            />

            {/* Active Shipments List */}
            <BuyerShipmentList shipments={shipmentItems} maxItems={4} showViewAll />
          </div>

          {/* Right Column - Quick Actions & Alerts */}
          <div className="space-y-8">
            {/* Quick Actions */}
            <BuyerQuickActions columns={2} />

            {/* Alerts */}
            <BuyerAlerts maxAlerts={3} />

            {/* Support Card */}
            <BuyerSupportCard />
          </div>
        </div>
      </div>
    </div>
  )
}
