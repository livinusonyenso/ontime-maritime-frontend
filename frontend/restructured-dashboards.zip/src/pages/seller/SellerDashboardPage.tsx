"use client"

import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import { useAuth } from "@/contexts/auth-context"
import { useSelector } from "react-redux"
import { selectSellerListings } from "@/store/slices/sellerListingSlice"
import type { MarketplaceListing } from "@/types/maritime"

// Seller-specific dashboard components
import {
  SellerDashboardHeader,
  SellerStatCard,
  SellerRevenueChart,
  SellerOrdersTable,
  SellerQuickActions,
  SellerGoalProgress,
  SellerListingsPreview,
} from "@/features/seller-dashboard/components"

// Modals from existing marketplace components (kept separate)
import { CreateListingModal } from "@/components/marketplace/CreateListingModal"
import { EditListingModal } from "@/components/marketplace/EditListingModal"

import { DollarSign, Package, Users, FileText, Store } from "lucide-react"

// Mock revenue data
const revenueChartData = [
  { name: "Jan", revenue: 12000, orders: 8 },
  { name: "Feb", revenue: 19000, orders: 12 },
  { name: "Mar", revenue: 15000, orders: 10 },
  { name: "Apr", revenue: 25000, orders: 18 },
  { name: "May", revenue: 32000, orders: 24 },
  { name: "Jun", revenue: 28000, orders: 20 },
]

export default function SellerDashboardPage() {
  const { user, isAuthenticated, loading, logout } = useAuth()
  const navigate = useNavigate()
  const myListings = useSelector(selectSellerListings)

  // Modal states
  const [createModalOpen, setCreateModalOpen] = useState(false)
  const [editingListing, setEditingListing] = useState<MarketplaceListing | null>(null)

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      navigate("/login")
    }
  }, [isAuthenticated, loading, navigate])

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="relative h-16 w-16">
            <div className="absolute inset-0 animate-ping rounded-full bg-amber-400 opacity-20"></div>
            <div className="relative flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-amber-500 to-orange-500">
              <Store className="h-8 w-8 text-white animate-pulse" />
            </div>
          </div>
          <p className="text-sm text-slate-500 dark:text-slate-400">Loading your dashboard...</p>
        </div>
      </div>
    )
  }

  if (!isAuthenticated) return null

  const userName = user?.first_name || "Seller"
  const businessName = user?.company_name

  // Calculate active listings
  const activeListings = myListings.filter(
    (l) => l.availability === "available"
  ).length

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white dark:from-slate-950 dark:to-slate-900">
      <div className="mx-auto max-w-7xl space-y-8 p-4 md:p-8">
        {/* Header Section */}
        <SellerDashboardHeader
          userName={userName}
          businessName={businessName}
          onLogout={logout}
          onCreateListing={() => setCreateModalOpen(true)}
        />

        {/* Stats Grid */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <SellerStatCard
            title="Total Revenue"
            value="$131,200"
            icon={DollarSign}
            accentColor="gold"
            trend={{ value: "+15%", positive: true }}
            subtitle="All-time earnings"
          />
          <SellerStatCard
            title="Active Listings"
            value={activeListings > 0 ? activeListings : 12}
            icon={Package}
            accentColor="emerald"
            trend={{ value: "+3 new", positive: true }}
            subtitle="Live on marketplace"
          />
          <SellerStatCard
            title="Total Customers"
            value="48"
            icon={Users}
            accentColor="violet"
            trend={{ value: "+2 this week", positive: true }}
            subtitle="Unique buyers"
          />
          <SellerStatCard
            title="Pending Orders"
            value="5"
            icon={FileText}
            accentColor="rose"
            subtitle="Awaiting action"
          />
        </div>

        {/* Main Content Grid */}
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Left Column - Charts & Orders */}
          <div className="space-y-8 lg:col-span-2">
            {/* Revenue Chart */}
            <SellerRevenueChart
              data={revenueChartData}
              title="Revenue Overview"
              description="Monthly revenue performance for the current year"
              totalRevenue={131200}
              revenueChange={15}
            />

            {/* Recent Orders Table */}
            <SellerOrdersTable maxOrders={5} showViewAll />
          </div>

          {/* Right Column - Quick Actions & Progress */}
          <div className="space-y-8">
            {/* Quick Actions */}
            <SellerQuickActions onCreateListing={() => setCreateModalOpen(true)} />

            {/* Monthly Goal Progress */}
            <SellerGoalProgress
              currentValue={45200}
              targetValue={50000}
              currency="$"
              period="Monthly"
            />
          </div>
        </div>

        {/* Listings Preview Section */}
        <SellerListingsPreview
          listings={myListings}
          maxListings={4}
          onEdit={setEditingListing}
          showViewAll
        />
      </div>

      {/* Create Listing Modal */}
      <CreateListingModal
        open={createModalOpen}
        onClose={() => setCreateModalOpen(false)}
      />

      {/* Edit Listing Modal */}
      {editingListing && (
        <EditListingModal
          open={!!editingListing}
          onClose={() => setEditingListing(null)}
          listing={editingListing}
        />
      )}
    </div>
  )
}
